let accordionTriggers = document.querySelectorAll(".accordion-toggle");
let firstAccs = document.querySelectorAll(".first-acc");

window.addEventListener("load", function () {
  firstAccs.forEach((firstAcc) => {
    let toggle = firstAcc.querySelector(".accordion-toggle");
    let panel = firstAcc.querySelector(".accordion-content");
    toggle.classList.add("active");
    panel.style.maxHeight = panel.scrollHeight + "px";
  });
});

accordionTriggers.forEach((trigger) =>
  trigger.addEventListener("click", function () {
    let open = trigger.classList.contains("active");
    let accordionContainer = trigger.parentElement.parentElement.parentElement;

    if (accordionContainer) {
      let accordionTriggers =
        accordionContainer.querySelectorAll(".accordion-toggle");

      accordionTriggers.forEach((trigger) => {
        let panel = trigger.nextElementSibling;
        trigger.classList.remove("active");
        panel.style.maxHeight = null;
      });
    }

    let panel = trigger.nextElementSibling;

    if (!open) {
      trigger.classList.add("active");
      panel.style.maxHeight = panel.scrollHeight + "px";
    } else {
      trigger.classList.remove("active");
      panel.style.maxHeight = null;
    }
  })
);
