//AOS Init
AOS.init({
  duration: 500,
});

//Menu responsive
let hamburger = document.querySelector(".hamburger");
let navResp = document.getElementById("navResp");

if (hamburger) {
  hamburger.addEventListener("click", function () {
    hamburger.classList.toggle("active");
    navResp.classList.toggle("active");
  });
}

//Header color change on scroll
let header = document.querySelector("header");

window.addEventListener("scroll", function () {
  if (window.scrollY >= 30) {
    header.classList.add("scrolled");
  } else {
    header.classList.remove("scrolled");
  }
});
